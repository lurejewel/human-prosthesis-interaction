#include "MocoReverseScaledControlTrackingGoal.h"

#include <OpenSim/Common/Object.h>

namespace {
struct RevGoalRegistrar {
    RevGoalRegistrar() {
        OpenSim::Object::registerType(
                OpenSim::MocoReverseScaledControlTrackingGoal());
        OpenSim::Object::registerType(
                OpenSim::MocoReverseScaledControlTrackingGoalReference());
    }
};
static RevGoalRegistrar registrar;
} // namespace
