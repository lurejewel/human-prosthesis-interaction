#include "MocoReverseScaledControlTrackingGoal.h"

#include <OpenSim/Moco/MocoStudy.h>
#include <OpenSim/Moco/MocoProblem.h>
#include <OpenSim/Moco/MocoCasADiSolver/MocoCasADiSolver.h>
#include <OpenSim/Simulation/TableProcessor.h>

#include <iostream>
#include <memory>
#include <string>

int main(int argc, char** argv) {
    if (argc < 4) {
        std::cerr << "usage: rev_driver study.xml reference.sto out.sto "
                     "[guess.sto]\n";
        return 1;
    }
    const std::string studyPath = argv[1];
    const std::string refPath = argv[2];
    const std::string outPath = argv[3];
    const std::string guessPath = (argc >= 5) ? argv[4] : "";

    OpenSim::MocoStudy study(studyPath);
    auto& problem = study.updProblem();
    std::cout << "problem model="
              << (const void*)&problem.getPhase(0).getModel() << "\n";

    auto* goal = new OpenSim::MocoReverseScaledControlTrackingGoal(
            "emg_tracking");
    goal->setReference(OpenSim::TableProcessor(refPath));
    goal->setWeight(20.0);

    const char* muscles[] = {
        "rect_fem_r", "vasti_r", "hamstrings_r", "tib_ant_r", "gastroc_r",
        "rect_fem_l", "vasti_l", "hamstrings_l", "tib_ant_l", "gastroc_l"};
    for (const char* m : muscles) {
        const std::string control = std::string("/forceset/") + m;
        goal->setReferenceLabel(control, control);
        goal->addScaleFactor(std::string("gain_") + m, control,
                             OpenSim::MocoBounds(0.5, 2.0));
    }
    problem.addGoal(std::unique_ptr<OpenSim::MocoGoal>(goal));

    auto* solver = OpenSim::MocoCasADiSolver::safeDownCast(&study.updSolver());
    solver->resetProblem(problem);
    solver->set_parameters_require_initsystem(false);
    std::cout << "sparsity=" << solver->get_optim_sparsity_detection()
              << " fd=" << solver->get_optim_finite_difference_scheme()
              << "\n";
    solver->set_optim_sparsity_detection("none");
    solver->set_optim_max_iterations(0);
    if (!guessPath.empty()) {
        solver->setGuess(OpenSim::MocoTrajectory(guessPath));
        std::cout << "guess=" << guessPath << "\n";
    }

    OpenSim::MocoSolution sol = study.solve();
    try {
        std::cout << "objective_at_guess=" << sol.getObjective() << "\n";
    } catch (const std::exception& e) {
        std::cout << "objective_at_guess unavailable: " << e.what() << "\n";
    }
    try {
        sol.write(outPath);
    } catch (const std::exception& e) {
        std::cout << "write failed: " << e.what() << "\n";
    }
    for (const char* m : muscles) {
        std::cout << m << " s=" << sol.getParameter(std::string("gain_") + m)
                  << "\n";
    }
    return 0;
}

